n = 32

szin = []
szam = []

for i in range(n):
    sor = int(input().split())
    szin.append(sor[0])
    szam.append(sor[1])
print(szin, szam)

